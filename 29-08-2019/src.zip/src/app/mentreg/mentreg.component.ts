import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentreg',
  templateUrl: './mentreg.component.html',
  styleUrls: ['./mentreg.component.css']
})
export class MentregComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
