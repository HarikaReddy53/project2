import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentregComponent } from './mentreg.component';

describe('MentregComponent', () => {
  let component: MentregComponent;
  let fixture: ComponentFixture<MentregComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentregComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentregComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
