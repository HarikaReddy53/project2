import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymenthistory',
  templateUrl: './paymenthistory.component.html',
  styleUrls: ['./paymenthistory.component.css']
})
export class PaymenthistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
