import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentexpComponent } from './mentexp.component';

describe('MentexpComponent', () => {
  let component: MentexpComponent;
  let fixture: ComponentFixture<MentexpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentexpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentexpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
