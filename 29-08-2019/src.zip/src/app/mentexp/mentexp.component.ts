import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentexp',
  templateUrl: './mentexp.component.html',
  styleUrls: ['./mentexp.component.css']
})
export class MentexpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
