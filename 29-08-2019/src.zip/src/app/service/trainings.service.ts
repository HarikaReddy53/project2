import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TrainingsService {
  
   


  

    constructor(private http: HttpClient) { }
 
    baseUrl: string = 'http://localhost:8089/api/trainings';
   
  
    getAllTraining():  Observable<any> {
      return this.http.get(`${this.baseUrl}/getAllTraining`);
    }
    getCompleted(user_id: number): Observable<any> {
      return this.http.get(`${this.baseUrl}/getCompleted/`+user_id);
    }
    getCompletedMentor(user_id: number): Observable<any> {
      return this.http.get(`${this.baseUrl}/getCompletedMentor/`+user_id);
    }
    getOnProgress(user_id: number): Observable<any> {
      return this.http.get(`${this.baseUrl}/getOnProgress/`+user_id);
    }
    getOnProgressMentor(user_id: number): Observable<any> {
      return this.http.get(`${this.baseUrl}/getOnProgressMentor/`+user_id);
    }
  }

