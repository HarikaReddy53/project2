import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentpaypendingComponent } from './mentpaypending.component';

describe('MentpaypendingComponent', () => {
  let component: MentpaypendingComponent;
  let fixture: ComponentFixture<MentpaypendingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentpaypendingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentpaypendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
