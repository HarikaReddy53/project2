import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentpaypending',
  templateUrl: './mentpaypending.component.html',
  styleUrls: ['./mentpaypending.component.css']
})
export class MentpaypendingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
