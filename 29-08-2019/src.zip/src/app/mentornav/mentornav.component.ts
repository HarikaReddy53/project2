import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentornav',
  templateUrl: './mentornav.component.html',
  styleUrls: ['./mentornav.component.css']
})
export class MentornavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
