export class MentorSkill{
    msid:number;
    mid:number;
    skill_id:number;
    skill_name:string;
    rating:number;
    trainings_delivered:string;
    facilities_offered:string;
}