import { Component, OnInit } from '@angular/core';

import * as $ from 'jquery';
import { MentorskillService } from '../service/mentorskill.service';
import { MentorSkill } from '../model/mentorskill';

@Component({
  selector: 'app-mentorsearch',
  templateUrl: './mentorsearch.component.html',
  styleUrls: ['./mentorsearch.component.css']
})
export class MentorsearchComponent implements OnInit {

  skills:MentorSkill;
  constructor(private MentorskillService:MentorskillService) {}

  ngOnInit() {
    this.MentorskillService.getAllSkills()
    .subscribe( data => {
    this.skills=data;
      console.log(data);
    });
    $(document).ready(
      function(){
        $("#search").on(
          "keyup",
          function(){
            var value=$(this).val().toLowerCase();
            $(".d1").filter(
              function(){
                $(this).toggle(
                  $(this).text().toLowerCase()
                  .indexOf(value) > -1)
                
              }
            );
          }
        );
      }
    );
  }

}
