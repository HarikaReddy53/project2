package com.java.repo;

import java.util.List;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.java.model.Trainings;

@Repository
public interface TrainingsRepository extends CrudRepository<Trainings, Long> {

	
	@Query(value="SELECT * FROM trainings  WHERE trainings.status=? AND trainings.user_id=?", nativeQuery=true)
	public List<Trainings> getAllCompletedTraining(@Param("status") String  status,@Param("user_id") long  user_id);
	@Query(value="SELECT * FROM trainings  WHERE trainings.status='5' AND trainings.mentor_id=?", nativeQuery=true)
	public List<Trainings> getAllCompletedTrainingMentor(@Param("mentor_id") long  mentor_id);
	
	
	@Query(value="SELECT * FROM trainings   WHERE trainings.status!='complete' AND trainings.user_id=?", nativeQuery=true)
	public List<Trainings> getAllOnProgress(@Param("user_id") long  user_id);
	
	@Query(value="SELECT * FROM trainings   WHERE trainings.status='Finalize'", nativeQuery=true)
	public List<Trainings> getAllFinalize(@Param("tid") long  tid);
	
	@Query(value="SELECT * FROM trainings   WHERE trainings.status='proposed'", nativeQuery=true)
	public List<Trainings> getAllApprove(@Param("tid") long  tid);


//	public List<Trainings> getAllCompletedTraining(long user_id);
	


}
