package com.java.repo;

import org.springframework.data.repository.CrudRepository;

import com.java.model.Mentor;

public interface MentorRepository extends CrudRepository<Mentor, Long>{

}
